<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Materi extends Model
{
    protected $fillable = ['judul', 'deskripsi'];

    public function pengunggah()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
