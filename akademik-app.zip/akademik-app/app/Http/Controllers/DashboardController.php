<?php

namespace App\Http\Controllers;

use App\Models\Materi;
use App\Models\Nilai;
use App\Models\User;

class DashboardController extends Controller
{
    public function index()
    {
        $user = auth()->user();

        $stat = match ($user->role) {
            'admin' => ['Pengguna' => User::count(), 'Materi' => Materi::count(), 'Nilai' => Nilai::count()],
            'dosen' => ['Materi' => Materi::count(), 'Nilai' => Nilai::count()],
            default => ['Materi' => Materi::count(), 'Nilai saya' => $user->nilais()->count()],
        };

        return view('dashboard', compact('stat'));
    }
}
