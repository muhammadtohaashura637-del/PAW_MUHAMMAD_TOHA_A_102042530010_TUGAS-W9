<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class UserController extends Controller
{
    public function index()
    {
        return view('users.index', ['users' => User::orderBy('name')->get()]);
    }

    public function create()
    {
        return view('users.form', ['user' => new User(['role' => 'mahasiswa'])]);
    }

    public function store(Request $request)
    {
        $data = $this->validated($request);

        $user = new User(collect($data)->only('name', 'email', 'password')->all());
        $user->role = $data['role']; // role ditetapkan di sisi server (hanya admin yang sampai sini)
        $user->save();

        return redirect()->route('users.index')->with('status', 'Pengguna ditambahkan.');
    }

    public function edit(User $user)
    {
        return view('users.form', compact('user'));
    }

    public function update(Request $request, User $user)
    {
        $data = $this->validated($request, $user);

        $user->fill(collect($data)->only('name', 'email')->all());
        if (!empty($data['password'])) {
            $user->password = $data['password'];
        }
        $user->role = $data['role'];
        $user->save();

        return redirect()->route('users.index')->with('status', 'Pengguna diperbarui.');
    }

    public function destroy(User $user)
    {
        if ($user->is(auth()->user())) {
            return back()->withErrors(['hapus' => 'Anda tidak dapat menghapus akun sendiri.']);
        }
        $user->delete();

        return redirect()->route('users.index')->with('status', 'Pengguna dihapus.');
    }

    private function validated(Request $request, ?User $user = null): array
    {
        return $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', Rule::unique('users', 'email')->ignore($user?->id)],
            'password' => [$user ? 'nullable' : 'required', 'string', 'min:8'],
            'role' => ['required', Rule::in(User::ROLES)],
        ]);
    }
}
