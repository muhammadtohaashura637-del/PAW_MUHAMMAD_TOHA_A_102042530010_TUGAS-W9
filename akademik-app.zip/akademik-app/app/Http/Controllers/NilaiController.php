<?php

namespace App\Http\Controllers;

use App\Models\Nilai;
use App\Models\User;
use Illuminate\Http\Request;

class NilaiController extends Controller
{
    public function index()
    {
        return view('nilai.index', ['nilais' => Nilai::with('mahasiswa')->latest()->get()]);
    }

    public function create()
    {
        return view('nilai.form', ['nilai' => new Nilai(), 'mahasiswa' => $this->daftarMahasiswa()]);
    }

    public function store(Request $request)
    {
        Nilai::create($this->validated($request));

        return redirect()->route('nilai.index')->with('status', 'Nilai ditambahkan.');
    }

    public function edit(Nilai $nilai)
    {
        return view('nilai.form', ['nilai' => $nilai, 'mahasiswa' => $this->daftarMahasiswa()]);
    }

    public function update(Request $request, Nilai $nilai)
    {
        $nilai->update($this->validated($request));

        return redirect()->route('nilai.index')->with('status', 'Nilai diperbarui.');
    }

    public function destroy(Nilai $nilai)
    {
        $nilai->delete();

        return redirect()->route('nilai.index')->with('status', 'Nilai dihapus.');
    }

    // Nilai pribadi: query dibatasi ke user yang login (kontrol tingkat data, bukan dari parameter URL)
    public function saya(Request $request)
    {
        return view('nilai.saya', ['nilais' => $request->user()->nilais()->latest()->get()]);
    }

    private function daftarMahasiswa()
    {
        return User::where('role', 'mahasiswa')->orderBy('name')->get();
    }

    private function validated(Request $request): array
    {
        return $request->validate([
            'user_id' => ['required', 'exists:users,id,role,mahasiswa'],
            'mata_kuliah' => ['required', 'string', 'max:255'],
            'nilai' => ['required', 'integer', 'between:0,100'],
        ]);
    }
}
