<?php

namespace App\Http\Controllers;

use App\Models\Materi;
use Illuminate\Http\Request;

class MateriController extends Controller
{
    // Lihat materi (semua role yang login)
    public function index()
    {
        return view('materi.index', ['materis' => Materi::with('pengunggah')->latest()->get(), 'kelola' => false]);
    }

    // Kelola materi (admin, dosen)
    public function kelola()
    {
        return view('materi.index', ['materis' => Materi::with('pengunggah')->latest()->get(), 'kelola' => true]);
    }

    public function create()
    {
        return view('materi.form', ['materi' => new Materi()]);
    }

    public function store(Request $request)
    {
        $materi = new Materi($this->validated($request));
        $materi->user_id = $request->user()->id;
        $materi->save();

        return redirect()->route('materi.kelola')->with('status', 'Materi ditambahkan.');
    }

    public function edit(Materi $materi)
    {
        return view('materi.form', compact('materi'));
    }

    public function update(Request $request, Materi $materi)
    {
        $materi->update($this->validated($request));

        return redirect()->route('materi.kelola')->with('status', 'Materi diperbarui.');
    }

    public function destroy(Materi $materi)
    {
        $materi->delete();

        return redirect()->route('materi.kelola')->with('status', 'Materi dihapus.');
    }

    private function validated(Request $request): array
    {
        return $request->validate([
            'judul' => ['required', 'string', 'max:255'],
            'deskripsi' => ['nullable', 'string'],
        ]);
    }
}
