# Aplikasi Akademik — Tugas Praktikum Middleware (Laravel 11/12)

Tiga role: **Admin**, **Dosen**, **Mahasiswa**. Akses dibatasi dengan Middleware `CheckRole` (alias `role`).

## 1. Instalasi

```bash
composer create-project laravel/laravel akademik-app
cd akademik-app
```

Salin **seluruh isi folder paket ini** ke dalam `akademik-app` (timpa file yang sama, mis. `bootstrap/app.php`, `app/Models/User.php`, `database/seeders/DatabaseSeeder.php`).

Atur database di `.env` (atau pakai SQLite bawaan Laravel), lalu:

```bash
php artisan migrate --seed
php artisan serve
```

Buka http://127.0.0.1:8000 → diarahkan ke `/login`.

## 2. Akun uji (password semua: `password`)

| Role | Email |
|---|---|
| Admin | admin@akademik.test |
| Dosen | dosen@akademik.test |
| Mahasiswa | mahasiswa@akademik.test |
| Mahasiswa 2 | mahasiswa2@akademik.test |

## 3. Pemetaan ke butir tugas

| Butir tugas | Lokasi |
|---|---|
| Login, logout, tabel users + kolom role | `AuthController`, view `auth/login`, migration `add_role_to_users_table` |
| Middleware `CheckRole` + alias `role` | `app/Http/Middleware/CheckRole.php`, `bootstrap/app.php` |
| Lindungi route pengguna, materi, nilai | `routes/web.php` |
| Uji ≥ 3 akun | akun seeder + `tests/Feature/RoleAccessTest.php` |
| Dokumentasi pengujian | bagian 5 di bawah |

## 4. Matriks akses (sesuai slide 8)

| Route | Middleware | Admin | Dosen | Mahasiswa |
|---|---|:-:|:-:|:-:|
| `/dashboard`, `/materi` | `auth` | ✓ | ✓ | ✓ |
| `/admin` | `auth, role:admin` | ✓ | ✗ | ✗ |
| `/dosen` | `auth, role:dosen` | ✗ | ✓ | ✗ |
| `/mahasiswa` | `auth, role:mahasiswa` | ✗ | ✗ | ✓ |
| `/users` (CRUD pengguna) | `auth, role:admin` | ✓ | ✗ | ✗ |
| `/kelola-materi`, `/materi/create|edit` | `auth, role:admin,dosen` | ✓ | ✓ | ✗ |
| `/nilai` (CRUD nilai) | `auth, role:admin,dosen` | ✓ | ✓ | ✗ |
| `/nilai-saya` | `auth, role:admin,mahasiswa` | ✓ | ✗ | ✓ |

Catatan keamanan yang diterapkan: role tidak ada di `$fillable` dan hanya ditetapkan oleh server/admin; `/nilai-saya` memakai `auth()->user()->nilais()` (bukan ID dari URL), sehingga mahasiswa tidak bisa melihat nilai orang lain; menu disembunyikan per role **dan** route dilindungi di server.

## 5. Dokumentasi pengujian

Jalankan otomatis: `php artisan test --filter=RoleAccessTest`
Lalu uji manual di browser dan **ganti kolom "Hasil aktual" + tempel screenshot** milik Anda.

| No | Pengguna | URL | Hasil diharapkan | Hasil aktual |
|---|---|---|---|---|
| 1 | Belum login | `/admin` | Redirect ke `/login` | |
| 2 | Admin | `/admin` | 200 OK (diizinkan) | |
| 3 | Admin | `/users` | 200 OK (diizinkan) | |
| 4 | Admin | `/kelola-materi` | 200 OK (diizinkan) | |
| 5 | Dosen | `/dosen` | 200 OK (diizinkan) | |
| 6 | Dosen | `/kelola-materi`, `/nilai` | 200 OK (diizinkan) | |
| 7 | Dosen | `/admin`, `/users` | **403** Anda tidak memiliki hak akses! | |
| 8 | Mahasiswa | `/mahasiswa`, `/nilai-saya` | 200 OK (diizinkan) | |
| 9 | Mahasiswa | `/kelola-materi`, `/nilai`, `/users` | **403** | |
| 10 | Mahasiswa | `/nilai-saya` | Hanya nilai milik sendiri | |
| 11 | Login salah password | `/login` | Pesan error, tidak masuk | |
| 12 | Logout | `/logout` (POST) | Kembali ke `/login`, sesi dihapus | |

Periksa juga daftar route: `php artisan route:list` (kolom middleware harus memuat `role:...`).
