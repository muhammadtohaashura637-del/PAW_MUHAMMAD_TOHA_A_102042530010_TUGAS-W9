<?php

namespace Database\Seeders;

use App\Models\Materi;
use App\Models\Nilai;
use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $akun = [
            ['Admin Akademik',   'admin@akademik.test',      'admin'],
            ['Dosen Pengampu',   'dosen@akademik.test',      'dosen'],
            ['Mahasiswa Satu',   'mahasiswa@akademik.test',  'mahasiswa'],
            ['Mahasiswa Dua',    'mahasiswa2@akademik.test', 'mahasiswa'],
        ];

        $users = [];
        foreach ($akun as [$name, $email, $role]) {
            $u = User::firstOrNew(['email' => $email]);
            $u->name = $name;
            $u->password = 'password'; // di-hash otomatis oleh cast 'hashed'
            $u->role = $role;          // role ditetapkan oleh sistem
            $u->save();
            $users[$role][] = $u;
        }

        Materi::firstOrCreate(['judul' => 'Pengantar Middleware'], [
            'deskripsi' => 'Konsep dan alur kerja middleware pada Laravel.',
            'user_id' => $users['dosen'][0]->id,
        ]);
        Materi::firstOrCreate(['judul' => 'RBAC dan Least Privilege'], [
            'deskripsi' => 'Pembatasan akses berdasarkan role.',
            'user_id' => $users['dosen'][0]->id,
        ]);

        foreach ($users['mahasiswa'] as $i => $m) {
            Nilai::firstOrCreate(['user_id' => $m->id, 'mata_kuliah' => 'Pemrograman Web'], ['nilai' => 85 - $i * 7]);
        }
    }
}
