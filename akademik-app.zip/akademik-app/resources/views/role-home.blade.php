@extends('layouts.app')
@section('content')
<div class="card"><h2>{{ $judul }}</h2><p>Anda masuk sebagai <b>{{ auth()->user()->role }}</b>.</p></div>
@endsection
