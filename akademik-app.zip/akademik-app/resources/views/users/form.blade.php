@extends('layouts.app')
@section('content')
<div class="card">
    <h2>{{ $user->exists ? 'Edit' : 'Tambah' }} Pengguna</h2>
    <form method="POST" action="{{ $user->exists ? route('users.update', $user) : route('users.store') }}">
        @csrf @if($user->exists) @method('PUT') @endif
        <label>Nama</label><input name="name" value="{{ old('name', $user->name) }}" required>
        <label>Email</label><input type="email" name="email" value="{{ old('email', $user->email) }}" required>
        <label>Password {{ $user->exists ? '(kosongkan jika tidak diubah)' : '' }}</label>
        <input type="password" name="password" {{ $user->exists ? '' : 'required' }}>
        <label>Role</label>
        <select name="role">
            @foreach(\App\Models\User::ROLES as $r)
                <option value="{{ $r }}" @selected(old('role', $user->role) === $r)>{{ $r }}</option>
            @endforeach
        </select>
        <button>Simpan</button> <a href="{{ route('users.index') }}">Batal</a>
    </form>
</div>
@endsection
