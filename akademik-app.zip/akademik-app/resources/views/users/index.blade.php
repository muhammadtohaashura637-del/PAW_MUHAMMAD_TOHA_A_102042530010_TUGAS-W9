@extends('layouts.app')
@section('content')
<div class="card">
    <h2>Manajemen Pengguna</h2>
    <a class="btn btn-red" href="{{ route('users.create') }}">+ Tambah</a><br><br>
    <table>
        <tr><th>Nama</th><th>Email</th><th>Role</th><th>Aksi</th></tr>
        @foreach($users as $u)
        <tr>
            <td>{{ $u->name }}</td><td>{{ $u->email }}</td><td>{{ $u->role }}</td>
            <td>
                <a href="{{ route('users.edit', $u) }}">Edit</a>
                <form class="inline" method="POST" action="{{ route('users.destroy', $u) }}" onsubmit="return confirm('Hapus pengguna?')">
                    @csrf @method('DELETE') <button class="btn-red">Hapus</button>
                </form>
            </td>
        </tr>
        @endforeach
    </table>
</div>
@endsection
