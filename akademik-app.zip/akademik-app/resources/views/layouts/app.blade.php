<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'Aplikasi Akademik')</title>
    <style>
        :root{--ink:#111d2e;--red:#e11d48;--bg:#f5f6fa;--line:#e2e5ee}
        *{box-sizing:border-box}
        body{margin:0;font-family:system-ui,Segoe UI,Arial,sans-serif;background:var(--bg);color:var(--ink)}
        nav{background:var(--ink);color:#fff;padding:12px 24px;display:flex;gap:16px;align-items:center;flex-wrap:wrap}
        nav a{color:#fff;text-decoration:none;font-size:14px}
        nav a:hover{text-decoration:underline}
        nav .brand{font-weight:700;margin-right:12px}
        nav .spacer{flex:1}
        .badge{background:var(--red);padding:2px 8px;border-radius:99px;font-size:12px}
        main{max-width:960px;margin:24px auto;padding:0 16px}
        .card{background:#fff;border:1px solid var(--line);border-radius:10px;padding:20px;margin-bottom:16px}
        table{width:100%;border-collapse:collapse}
        th{background:var(--ink);color:#fff;text-align:left}
        th,td{padding:8px 10px;border-bottom:1px solid var(--line);font-size:14px}
        input,select,textarea{width:100%;padding:8px;border:1px solid #c9cedb;border-radius:6px;font:inherit;margin:4px 0 12px}
        button,.btn{background:var(--ink);color:#fff;border:0;padding:8px 14px;border-radius:6px;cursor:pointer;text-decoration:none;font-size:14px;display:inline-block}
        .btn-red{background:var(--red)}
        .btn-link{background:none;color:#fff;padding:0}
        .ok{background:#dcfce7;border:1px solid #86efac;padding:10px;border-radius:6px;margin-bottom:12px}
        .err{background:#fee2e2;border:1px solid #fca5a5;padding:10px;border-radius:6px;margin-bottom:12px}
        .stats{display:flex;gap:16px;flex-wrap:wrap}
        .stat{flex:1;min-width:140px;text-align:center}
        .stat b{font-size:32px;display:block}
        form.inline{display:inline}
    </style>
</head>
<body>
@auth
<nav>
    <span class="brand">Akademik</span>
    <a href="{{ route('dashboard') }}">Dashboard</a>
    <a href="{{ route('materi.index') }}">Materi</a>
    {{-- Menu hanya UX. Pembatasan sebenarnya ada di route (middleware role). --}}
    @if(auth()->user()->hasRole('admin'))
        <a href="{{ route('users.index') }}">Pengguna</a>
    @endif
    @if(auth()->user()->hasRole('admin','dosen'))
        <a href="{{ route('materi.kelola') }}">Kelola Materi</a>
        <a href="{{ route('nilai.index') }}">Kelola Nilai</a>
    @endif
    @if(auth()->user()->hasRole('admin','mahasiswa'))
        <a href="{{ route('nilai.saya') }}">Nilai Saya</a>
    @endif
    <span class="spacer"></span>
    <span>{{ auth()->user()->name }} <span class="badge">{{ auth()->user()->role }}</span></span>
    <form method="POST" action="{{ route('logout') }}" class="inline">@csrf
        <button class="btn-link">Logout</button>
    </form>
</nav>
@endauth
<main>
    @if(session('status')) <div class="ok">{{ session('status') }}</div> @endif
    @if($errors->any()) <div class="err">@foreach($errors->all() as $e)<div>{{ $e }}</div>@endforeach</div> @endif
    @yield('content')
</main>
</body>
</html>
