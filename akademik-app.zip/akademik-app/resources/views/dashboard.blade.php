@extends('layouts.app')
@section('content')
<div class="card">
    <h2>Dashboard</h2>
    <p>Selamat datang, <b>{{ auth()->user()->name }}</b> (role: {{ auth()->user()->role }}).</p>
    <div class="stats">
        @foreach($stat as $label => $jumlah)
            <div class="card stat"><b>{{ $jumlah }}</b>{{ $label }}</div>
        @endforeach
    </div>
</div>
@endsection
