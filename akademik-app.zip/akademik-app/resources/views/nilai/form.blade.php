@extends('layouts.app')
@section('content')
<div class="card">
    <h2>{{ $nilai->exists ? 'Edit' : 'Tambah' }} Nilai</h2>
    <form method="POST" action="{{ $nilai->exists ? route('nilai.update', $nilai) : route('nilai.store') }}">
        @csrf @if($nilai->exists) @method('PUT') @endif
        <label>Mahasiswa</label>
        <select name="user_id">
            @foreach($mahasiswa as $m)
                <option value="{{ $m->id }}" @selected(old('user_id', $nilai->user_id) == $m->id)>{{ $m->name }}</option>
            @endforeach
        </select>
        <label>Mata Kuliah</label><input name="mata_kuliah" value="{{ old('mata_kuliah', $nilai->mata_kuliah) }}" required>
        <label>Nilai (0-100)</label><input type="number" name="nilai" min="0" max="100" value="{{ old('nilai', $nilai->nilai) }}" required>
        <button>Simpan</button> <a href="{{ route('nilai.index') }}">Batal</a>
    </form>
</div>
@endsection
