@extends('layouts.app')
@section('content')
<div class="card">
    <h2>Kelola Nilai</h2>
    <a class="btn btn-red" href="{{ route('nilai.create') }}">+ Tambah</a><br><br>
    <table>
        <tr><th>Mahasiswa</th><th>Mata Kuliah</th><th>Nilai</th><th>Aksi</th></tr>
        @forelse($nilais as $n)
        <tr>
            <td>{{ $n->mahasiswa->name }}</td><td>{{ $n->mata_kuliah }}</td><td>{{ $n->nilai }}</td>
            <td>
                <a href="{{ route('nilai.edit', $n) }}">Edit</a>
                <form class="inline" method="POST" action="{{ route('nilai.destroy', $n) }}" onsubmit="return confirm('Hapus nilai?')">
                    @csrf @method('DELETE') <button class="btn-red">Hapus</button>
                </form>
            </td>
        </tr>
        @empty <tr><td colspan="4">Belum ada nilai.</td></tr>
        @endforelse
    </table>
</div>
@endsection
