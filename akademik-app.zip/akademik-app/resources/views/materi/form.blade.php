@extends('layouts.app')
@section('content')
<div class="card">
    <h2>{{ $materi->exists ? 'Edit' : 'Tambah' }} Materi</h2>
    <form method="POST" action="{{ $materi->exists ? route('materi.update', $materi) : route('materi.store') }}">
        @csrf @if($materi->exists) @method('PUT') @endif
        <label>Judul</label><input name="judul" value="{{ old('judul', $materi->judul) }}" required>
        <label>Deskripsi</label><textarea name="deskripsi" rows="4">{{ old('deskripsi', $materi->deskripsi) }}</textarea>
        <button>Simpan</button> <a href="{{ route('materi.kelola') }}">Batal</a>
    </form>
</div>
@endsection
