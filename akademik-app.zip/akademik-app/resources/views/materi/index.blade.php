@extends('layouts.app')
@section('content')
<div class="card">
    <h2>{{ $kelola ? 'Kelola Materi' : 'Daftar Materi' }}</h2>
    @if($kelola)<a class="btn btn-red" href="{{ route('materi.create') }}">+ Tambah</a><br><br>@endif
    <table>
        <tr><th>Judul</th><th>Deskripsi</th><th>Pengunggah</th>@if($kelola)<th>Aksi</th>@endif</tr>
        @forelse($materis as $m)
        <tr>
            <td>{{ $m->judul }}</td><td>{{ $m->deskripsi }}</td><td>{{ $m->pengunggah->name }}</td>
            @if($kelola)
            <td>
                <a href="{{ route('materi.edit', $m) }}">Edit</a>
                <form class="inline" method="POST" action="{{ route('materi.destroy', $m) }}" onsubmit="return confirm('Hapus materi?')">
                    @csrf @method('DELETE') <button class="btn-red">Hapus</button>
                </form>
            </td>
            @endif
        </tr>
        @empty <tr><td colspan="4">Belum ada materi.</td></tr>
        @endforelse
    </table>
</div>
@endsection
