<!DOCTYPE html>
<html lang="id"><head><meta charset="utf-8"><title>403 - Akses Ditolak</title>
<style>body{font-family:system-ui,Arial;background:#f5f6fa;display:grid;place-items:center;height:100vh;margin:0;color:#111d2e}
.box{background:#fff;border:1px solid #e2e5ee;border-radius:10px;padding:32px 40px;text-align:center}
h1{color:#e11d48;font-size:64px;margin:0}a{color:#111d2e}</style></head>
<body><div class="box"><h1>403</h1><h3>Akses Ditolak</h3>
<p>{{ $exception->getMessage() ?: 'Anda tidak memiliki hak akses!' }}</p>
<a href="{{ url('/dashboard') }}">Kembali ke Dashboard</a></div></body></html>
