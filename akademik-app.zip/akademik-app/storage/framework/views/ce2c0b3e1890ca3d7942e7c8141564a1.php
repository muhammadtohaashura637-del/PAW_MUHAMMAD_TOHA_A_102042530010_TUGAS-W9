<?php $__env->startSection('content'); ?>
<div class="card">
    <h2><?php echo e($kelola ? 'Kelola Materi' : 'Daftar Materi'); ?></h2>
    <?php if($kelola): ?><a class="btn btn-red" href="<?php echo e(route('materi.create')); ?>">+ Tambah</a><br><br><?php endif; ?>
    <table>
        <tr><th>Judul</th><th>Deskripsi</th><th>Pengunggah</th><?php if($kelola): ?><th>Aksi</th><?php endif; ?></tr>
        <?php $__empty_1 = true; $__currentLoopData = $materis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($m->judul); ?></td><td><?php echo e($m->deskripsi); ?></td><td><?php echo e($m->pengunggah->name); ?></td>
            <?php if($kelola): ?>
            <td>
                <a href="<?php echo e(route('materi.edit', $m)); ?>">Edit</a>
                <form class="inline" method="POST" action="<?php echo e(route('materi.destroy', $m)); ?>" onsubmit="return confirm('Hapus materi?')">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?> <button class="btn-red">Hapus</button>
                </form>
            </td>
            <?php endif; ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <tr><td colspan="4">Belum ada materi.</td></tr>
        <?php endif; ?>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\LOQ\Downloads\akademik-app\resources\views/materi/index.blade.php ENDPATH**/ ?>