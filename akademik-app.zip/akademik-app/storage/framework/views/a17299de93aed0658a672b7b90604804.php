<?php $__env->startSection('content'); ?>
<div class="card"><h2><?php echo e($judul); ?></h2><p>Anda masuk sebagai <b><?php echo e(auth()->user()->role); ?></b>.</p></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\LOQ\Downloads\akademik-app\resources\views/role-home.blade.php ENDPATH**/ ?>