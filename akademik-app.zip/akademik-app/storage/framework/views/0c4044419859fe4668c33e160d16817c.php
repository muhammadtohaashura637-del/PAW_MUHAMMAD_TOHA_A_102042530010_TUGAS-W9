<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->startSection('content'); ?>
<div class="card" style="max-width:420px;margin:60px auto">
    <h2>Login Aplikasi Akademik</h2>
    <form method="POST" action="<?php echo e(url('/login')); ?>">
        <?php echo csrf_field(); ?>
        <label>Email</label>
        <input type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
        <label>Password</label>
        <input type="password" name="password" required>
        <label><input type="checkbox" name="remember" style="width:auto"> Ingat saya</label><br><br>
        <button>Masuk</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\LOQ\Downloads\akademik-app\resources\views/auth/login.blade.php ENDPATH**/ ?>