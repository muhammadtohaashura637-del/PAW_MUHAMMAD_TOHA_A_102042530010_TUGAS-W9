<?php $__env->startSection('content'); ?>
<div class="card">
    <h2>Nilai Saya</h2>
    <table>
        <tr><th>Mata Kuliah</th><th>Nilai</th></tr>
        <?php $__empty_1 = true; $__currentLoopData = $nilais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><?php echo e($n->mata_kuliah); ?></td><td><?php echo e($n->nilai); ?></td></tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <tr><td colspan="2">Belum ada nilai.</td></tr>
        <?php endif; ?>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\LOQ\Downloads\akademik-app\resources\views/nilai/saya.blade.php ENDPATH**/ ?>