<?php $__env->startSection('content'); ?>
<div class="card">
    <h2>Dashboard</h2>
    <p>Selamat datang, <b><?php echo e(auth()->user()->name); ?></b> (role: <?php echo e(auth()->user()->role); ?>).</p>
    <div class="stats">
        <?php $__currentLoopData = $stat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $jumlah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card stat"><b><?php echo e($jumlah); ?></b><?php echo e($label); ?></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\LOQ\Downloads\akademik-app\resources\views/dashboard.blade.php ENDPATH**/ ?>