<?php $__env->startSection('content'); ?>
<div class="card">
    <h2>Kelola Nilai</h2>
    <a class="btn btn-red" href="<?php echo e(route('nilai.create')); ?>">+ Tambah</a><br><br>
    <table>
        <tr><th>Mahasiswa</th><th>Mata Kuliah</th><th>Nilai</th><th>Aksi</th></tr>
        <?php $__empty_1 = true; $__currentLoopData = $nilais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($n->mahasiswa->name); ?></td><td><?php echo e($n->mata_kuliah); ?></td><td><?php echo e($n->nilai); ?></td>
            <td>
                <a href="<?php echo e(route('nilai.edit', $n)); ?>">Edit</a>
                <form class="inline" method="POST" action="<?php echo e(route('nilai.destroy', $n)); ?>" onsubmit="return confirm('Hapus nilai?')">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?> <button class="btn-red">Hapus</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <tr><td colspan="4">Belum ada nilai.</td></tr>
        <?php endif; ?>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\LOQ\Downloads\akademik-app\resources\views/nilai/index.blade.php ENDPATH**/ ?>