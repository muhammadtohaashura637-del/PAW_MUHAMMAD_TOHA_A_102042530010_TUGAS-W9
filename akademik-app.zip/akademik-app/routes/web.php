<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\MateriController;
use App\Http\Controllers\NilaiController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

Route::get('/', fn () => redirect()->route('dashboard'));

// ---------- Autentikasi ----------
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:10,1');
});
Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth')->name('logout');

// ---------- Semua role (harus login) ----------
Route::middleware('auth')->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/materi', [MateriController::class, 'index'])->name('materi.index'); // Lihat materi: semua role
});

// ---------- Halaman per role ----------
Route::middleware(['auth', 'role:admin'])->get('/admin', fn () => view('role-home', ['judul' => 'Halaman Admin']))->name('admin.home');
Route::middleware(['auth', 'role:dosen'])->get('/dosen', fn () => view('role-home', ['judul' => 'Dashboard Dosen']))->name('dosen.home');
Route::middleware(['auth', 'role:mahasiswa'])->get('/mahasiswa', fn () => view('role-home', ['judul' => 'Dashboard Mahasiswa']))->name('mahasiswa.home');

// ---------- Manajemen pengguna: HANYA admin ----------
Route::middleware(['auth', 'role:admin'])->group(function () {
    Route::resource('users', UserController::class)->except('show');
});

// ---------- Kelola materi: admin & dosen ----------
Route::middleware(['auth', 'role:admin,dosen'])->group(function () {
    Route::get('/kelola-materi', [MateriController::class, 'kelola'])->name('materi.kelola');
    Route::resource('materi', MateriController::class)->except(['index', 'show']);
});

// ---------- Kelola nilai: admin & dosen ----------
Route::middleware(['auth', 'role:admin,dosen'])->group(function () {
    Route::resource('nilai', NilaiController::class)->except('show');
});

// ---------- Nilai pribadi: mahasiswa (dan admin sesuai matriks) ----------
Route::middleware(['auth', 'role:admin,mahasiswa'])->get('/nilai-saya', [NilaiController::class, 'saya'])->name('nilai.saya');
