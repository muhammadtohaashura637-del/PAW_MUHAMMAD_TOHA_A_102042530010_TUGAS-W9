<?php

namespace Tests\Feature;

use App\Models\Nilai;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class RoleAccessTest extends TestCase
{
    use RefreshDatabase;

    private function akun(string $role): User
    {
        return User::factory()->create(['role' => $role]);
    }

    // ---- Skenario dari materi (slide 15) ----
    public function test_admin_boleh_ke_admin_dan_kelola_materi(): void
    {
        $a = $this->akun('admin');
        $this->actingAs($a)->get('/admin')->assertOk();
        $this->actingAs($a)->get('/kelola-materi')->assertOk();
    }

    public function test_dosen_boleh_dosen_ditolak_admin(): void
    {
        $d = $this->akun('dosen');
        $this->actingAs($d)->get('/dosen')->assertOk();
        $this->actingAs($d)->get('/admin')->assertForbidden();
        $this->actingAs($d)->get('/users')->assertForbidden();
    }

    public function test_mahasiswa_boleh_mahasiswa_ditolak_kelola(): void
    {
        $m = $this->akun('mahasiswa');
        $this->actingAs($m)->get('/mahasiswa')->assertOk();
        $this->actingAs($m)->get('/kelola-materi')->assertForbidden();
        $this->actingAs($m)->get('/users')->assertForbidden();
        $this->actingAs($m)->get('/nilai')->assertForbidden();
        $this->actingAs($m)->post('/nilai', [])->assertForbidden();
    }

    public function test_belum_login_dialihkan_ke_login(): void
    {
        foreach (['/admin', '/users', '/kelola-materi', '/nilai', '/nilai-saya', '/materi'] as $url) {
            $this->get($url)->assertRedirect('/login');
        }
    }

    // ---- Matriks fitur (slide 8) ----
    public function test_semua_role_boleh_dashboard_dan_lihat_materi(): void
    {
        foreach (['admin', 'dosen', 'mahasiswa'] as $role) {
            $u = $this->akun($role);
            $this->actingAs($u)->get('/dashboard')->assertOk();
            $this->actingAs($u)->get('/materi')->assertOk();
        }
    }

    public function test_dosen_boleh_kelola_nilai_tapi_tidak_lihat_nilai_pribadi(): void
    {
        $d = $this->akun('dosen');
        $this->actingAs($d)->get('/nilai')->assertOk();
        $this->actingAs($d)->get('/nilai-saya')->assertForbidden();
    }

    public function test_mahasiswa_hanya_melihat_nilai_sendiri(): void
    {
        $m1 = $this->akun('mahasiswa');
        $m2 = $this->akun('mahasiswa');
        Nilai::create(['user_id' => $m1->id, 'mata_kuliah' => 'MK-Milik-Saya', 'nilai' => 90]);
        Nilai::create(['user_id' => $m2->id, 'mata_kuliah' => 'MK-Milik-Orang-Lain', 'nilai' => 70]);

        $this->actingAs($m1)->get('/nilai-saya')
            ->assertOk()->assertSee('MK-Milik-Saya')->assertDontSee('MK-Milik-Orang-Lain');
    }

    // ---- Autentikasi ----
    public function test_login_logout(): void
    {
        $u = User::factory()->create(['role' => 'dosen', 'password' => 'rahasia123']);

        $this->post('/login', ['email' => $u->email, 'password' => 'salah'])->assertSessionHasErrors('email');
        $this->post('/login', ['email' => $u->email, 'password' => 'rahasia123'])->assertRedirect('/dashboard');
        $this->assertAuthenticatedAs($u);

        $this->post('/logout')->assertRedirect('/login');
        $this->assertGuest();
    }

    // ---- Role tidak bisa dimanipulasi dari input pengguna ----
    public function test_role_tidak_bisa_dinaikkan_lewat_mass_assignment(): void
    {
        $u = new User(['name' => 'X', 'email' => 'x@x.test', 'password' => 'password', 'role' => 'admin']);
        $u->save();
        $this->assertSame('mahasiswa', $u->fresh()->role); // tetap default
    }
}
